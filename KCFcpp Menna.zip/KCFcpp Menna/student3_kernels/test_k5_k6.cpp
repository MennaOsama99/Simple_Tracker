#include <iostream>
#include <vector>
#include <cmath>
#include <cassert>

extern void complex_multiply_scalar(const float*, const float*, const float*, const float*, float*, float*, int);
extern void gaussian_correlation_scalar(const float*, float*, float, float, float, int);
extern float compute_norm_squared_scalar(const float*, const float*, int);
extern void find_peak_subpixel_scalar(const float*, int, int, float&, int&, int&, float&, float&);

int main() {
    std::cout << "Running K5 & K6 Scalar Unit Tests...\n";

    // Test K5.1: Complex Multiply
    {
        int size = 4;
        std::vector<float> a_re = {1, 2, 3, 4}, a_im = {0, 1, 0, 1};
        std::vector<float> b_re = {1, 1, 1, 1}, b_im = {1, 0, 1, 0};
        std::vector<float> out_re(size), out_im(size);
        
        complex_multiply_scalar(a_re.data(), a_im.data(), b_re.data(), b_im.data(), out_re.data(), out_im.data(), size);
        
        assert(out_re[0] == 1.0f && out_im[0] == 1.0f);
        assert(out_re[1] == 2.0f && out_im[1] == 1.0f);
        std::cout << "[PASS] K5.1 Complex Multiply\n";
    }

    // Test K5.2 & K5.3: Gaussian Correlation
    {
        int size = 3;
        std::vector<float> re = {1, 2, 3}, im = {0, 0, 0};
        float norm = compute_norm_squared_scalar(re.data(), im.data(), size);
        assert(norm == 14.0f);
        
        std::vector<float> corr = {10.0f, 5.0f, 0.0f};
        std::vector<float> kernel(size);
        
        gaussian_correlation_scalar(corr.data(), kernel.data(), 14.0f, 14.0f, 2.0f, size);
        
        std::cout << "       Kernel values: [" << kernel[0] << ", " << kernel[1] << ", " << kernel[2] << "]\n";
        
        // Added 1e-5f epsilon to prevent strict floating-point equality failures
        assert(kernel[0] > kernel[1] + 1e-5f);
        assert(kernel[1] > kernel[2] + 1e-5f);
        assert(kernel[0] > 0.0f && kernel[0] <= 1.0f);
        std::cout << "[PASS] K5.2/3 Gaussian Correlation & Norms\n";
    }

    // Test K6: Peak Detection
    {
        int rows = 5, cols = 5;
        std::vector<float> response(rows * cols, 0.0f);
        response[2 * cols + 2] = 10.0f;
        response[2 * cols + 1] = 5.0f;
        response[2 * cols + 3] = 5.0f;
        response[1 * cols + 2] = 5.0f;
        response[3 * cols + 2] = 5.0f;
        
        float max_val, sub_x, sub_y;
        int max_x, max_y;
        
        find_peak_subpixel_scalar(response.data(), rows, cols, max_val, max_x, max_y, sub_x, sub_y);
        
        assert(max_x == 2 && max_y == 2);
        assert(max_val == 10.0f);
        assert(fabs(sub_x - 2.0f) < 0.01f && fabs(sub_y - 2.0f) < 0.01f);
        std::cout << "[PASS] K6 Peak Detection & Subpixel\n";
    }

    std::cout << "All tests passed successfully!\n";
    return 0;
}
