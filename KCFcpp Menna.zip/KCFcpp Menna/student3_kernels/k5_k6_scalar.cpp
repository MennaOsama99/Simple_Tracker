#include <iostream>
#include <vector>
#include <cmath>
#include <cfloat>

void complex_multiply_scalar(const float* a_re, const float* a_im,
                             const float* b_re, const float* b_im,
                             float* out_re, float* out_im, int size) {
    for (int i = 0; i < size; i++) {
        float ar = a_re[i];
        float ai = a_im[i];
        float br = b_re[i];
        float bi = b_im[i];
        out_re[i] = ar * br - ai * bi;
        out_im[i] = ar * bi + ai * br;
    }
}

void gaussian_correlation_scalar(const float* corr_real, float* kernel_out,
                                 float norm_x, float norm_z, float sigma, int size) {
    float coef = -1.0f / (sigma * sigma);
    float norm_sum = norm_x + norm_z;
    for (int i = 0; i < size; i++) {
        float dist = norm_sum - 2.0f * corr_real[i];
        float val = coef * dist;
        if (val < -100.0f) val = -100.0f; 
        kernel_out[i] = expf(val);
    }
}

float compute_norm_squared_scalar(const float* re, const float* im, int size) {
    float sum = 0.0f;
    for (int i = 0; i < size; i++) {
        sum += re[i] * re[i] + im[i] * im[i];
    }
    return sum;
}

void find_peak_subpixel_scalar(const float* response, int rows, int cols,
                               float& max_val, int& max_x, int& max_y,
                               float& sub_x, float& sub_y) {
    max_val = -FLT_MAX;
    max_x = 0; max_y = 0;
    int total = rows * cols;
    for (int i = 0; i < total; i++) {
        if (response[i] > max_val) {
            max_val = response[i];
            max_y = i / cols;
            max_x = i % cols;
        }
    }
    int x_left   = (max_x > 0) ? max_x - 1 : max_x;
    int x_right  = (max_x < cols - 1) ? max_x + 1 : max_x;
    int y_top    = (max_y > 0) ? max_y - 1 : max_y;
    int y_bottom = (max_y < rows - 1) ? max_y + 1 : max_y;

    float center = response[max_y * cols + max_x];
    float left   = response[max_y * cols + x_left];
    float right  = response[max_y * cols + x_right];
    float top    = response[y_top * cols + max_x];
    float bottom = response[y_bottom * cols + max_x];

    float denom_x = left - 2.0f * center + right;
    float offset_x = 0.0f;
    if (fabs(denom_x) > 1e-6f) {
        offset_x = 0.5f * (left - right) / denom_x;
        if (offset_x > 0.5f) offset_x = 0.5f;
        if (offset_x < -0.5f) offset_x = -0.5f;
    }

    float denom_y = top - 2.0f * center + bottom;
    float offset_y = 0.0f;
    if (fabs(denom_y) > 1e-6f) {
        offset_y = 0.5f * (top - bottom) / denom_y;
        if (offset_y > 0.5f) offset_y = 0.5f;
        if (offset_y < -0.5f) offset_y = -0.5f;
    }
    sub_x = (float)max_x + offset_x;
    sub_y = (float)max_y + offset_y;
}
