#include <iostream>
#include <vector>
#include <cmath>
#include <cfloat>
#include <cstddef>
#include <riscv_vector.h>

static inline vfloat32m4_t vec_exp_approx(vfloat32m4_t x, size_t vl) {
    vfloat32m4_t x2 = __riscv_vfmul_vv_f32m4(x, x, vl);
    vfloat32m4_t x3 = __riscv_vfmul_vv_f32m4(x2, x, vl);
    vfloat32m4_t x4 = __riscv_vfmul_vv_f32m4(x3, x, vl);
    
    vfloat32m4_t res = __riscv_vfmv_v_f_f32m4(1.0f, vl);
    res = __riscv_vfadd_vv_f32m4(res, x, vl);
    res = __riscv_vfmacc_vf_f32m4(res, 0.5f, x2, vl);
    res = __riscv_vfmacc_vf_f32m4(res, 0.16666667f, x3, vl);
    res = __riscv_vfmacc_vf_f32m4(res, 0.04166667f, x4, vl);
    return res;
}

void complex_multiply_rvv(const float* a_re, const float* a_im,
                          const float* b_re, const float* b_im,
                          float* out_re, float* out_im, int size) {
    size_t vl;
    for (int i = 0; i < size; i += vl) {
        vl = __riscv_vsetvl_e32m4(size - i);
        
        vfloat32m4_t ar = __riscv_vle32_v_f32m4(&a_re[i], vl);
        vfloat32m4_t ai = __riscv_vle32_v_f32m4(&a_im[i], vl);
        vfloat32m4_t br = __riscv_vle32_v_f32m4(&b_re[i], vl);
        vfloat32m4_t bi = __riscv_vle32_v_f32m4(&b_im[i], vl);
        
        vfloat32m4_t out_r = __riscv_vfnmsac_vv_f32m4(
            __riscv_vfmul_vv_f32m4(ar, br, vl), ai, bi, vl);
        
        vfloat32m4_t out_i = __riscv_vfmacc_vv_f32m4(
            __riscv_vfmul_vv_f32m4(ar, bi, vl), ai, br, vl);
        
        __riscv_vse32_v_f32m4(&out_re[i], out_r, vl);
        __riscv_vse32_v_f32m4(&out_im[i], out_i, vl);
    }
}

void gaussian_correlation_rvv(const float* corr_real, float* kernel_out,
                              float norm_x, float norm_z, float sigma, int size) {
    float coef = -1.0f / (sigma * sigma);
    float norm_sum = norm_x + norm_z;
    size_t vl;
    
    for (int i = 0; i < size; i += vl) {
        vl = __riscv_vsetvl_e32m4(size - i);
        
        vfloat32m4_t v_norm_sum = __riscv_vfmv_v_f_f32m4(norm_sum, vl);
        vfloat32m4_t corr = __riscv_vle32_v_f32m4(&corr_real[i], vl);
        
        // FIXED: vfmsub.vf computes: vd = vs1 - (rs2 * vs3)
        // So it must be: v_norm_sum - (2.0f * corr)
        vfloat32m4_t dist = __riscv_vfmsub_vf_f32m4(v_norm_sum, 2.0f, corr, vl);
        
        // exponent = coef * dist
        vfloat32m4_t exponent = __riscv_vfmul_vf_f32m4(dist, coef, vl);
        
        // Clamp: if exponent < -10.0f, set to -10.0f
        vbool8_t mask = __riscv_vmflt_vf_f32m4_b8(exponent, -10.0f, vl);
        vfloat32m4_t v_clamp = __riscv_vfmv_v_f_f32m4(-10.0f, vl);
        exponent = __riscv_vmerge_vvm_f32m4(exponent, v_clamp, mask, vl);
        
        // Compute exp(exponent) using approximation
        vfloat32m4_t result = vec_exp_approx(exponent, vl);
        __riscv_vse32_v_f32m4(&kernel_out[i], result, vl);
    }
}

void find_max_rvv(const float* response, int size, float& max_val, int& max_idx) {
    max_val = -FLT_MAX;
    max_idx = -1;
    size_t vl;
    
    for (int i = 0; i < size; i += vl) {
        vl = __riscv_vsetvl_e32m4(size - i);
        
        vfloat32m4_t v = __riscv_vle32_v_f32m4(&response[i], vl);
        vfloat32m1_t chunk_max_v = __riscv_vfredmax_vs_f32m4_f32m1(
            v, __riscv_vfmv_v_f_f32m1(-FLT_MAX, 1), vl);
        float chunk_max = __riscv_vfmv_f_s_f32m1_f32(chunk_max_v);
        
        if (chunk_max > max_val) {
            for (size_t j = 0; j < vl; j++) {
                if (response[i + j] > max_val) {
                    max_val = response[i + j];
                    max_idx = i + j;
                }
            }
        }
    }
}

void find_peak_subpixel_rvv(const float* response, int rows, int cols,
                            float& max_val, int& max_x, int& max_y,
                            float& sub_x, float& sub_y) {
    int max_idx;
    find_max_rvv(response, rows * cols, max_val, max_idx);
    
    max_y = max_idx / cols;
    max_x = max_idx % cols;
    
    int x_left   = (max_x > 0) ? max_x - 1 : max_x;
    int x_right  = (max_x < cols - 1) ? max_x + 1 : max_x;
    int y_top    = (max_y > 0) ? max_y - 1 : max_y;
    int y_bottom = (max_y < rows - 1) ? max_y + 1 : max_y;

    float center = response[max_y * cols + max_x];
    float left   = response[max_y * cols + x_left];
    float right  = response[max_y * cols + x_right];
    float top    = response[y_top * cols + max_x];
    float bottom = response[y_bottom * cols + max_x];

    float denom_x = left - 2.0f * center + right;
    float offset_x = 0.0f;
    if (fabs(denom_x) > 1e-6f) {
        offset_x = 0.5f * (left - right) / denom_x;
        if (offset_x > 0.5f) offset_x = 0.5f;
        if (offset_x < -0.5f) offset_x = -0.5f;
    }

    float denom_y = top - 2.0f * center + bottom;
    float offset_y = 0.0f;
    if (fabs(denom_y) > 1e-6f) {
        offset_y = 0.5f * (top - bottom) / denom_y;
        if (offset_y > 0.5f) offset_y = 0.5f;
        if (offset_y < -0.5f) offset_y = -0.5f;
    }
    sub_x = (float)max_x + offset_x;
    sub_y = (float)max_y + offset_y;
}
