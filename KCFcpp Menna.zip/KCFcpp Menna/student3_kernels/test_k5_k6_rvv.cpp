// student3_kernels/test_k5_k6_rvv.cpp
#include <iostream>
#include <vector>
#include <cmath>
#include <cassert>

// Declare Scalar functions
extern void complex_multiply_scalar(const float*, const float*, const float*, const float*, float*, float*, int);
extern void gaussian_correlation_scalar(const float*, float*, float, float, float, int);
extern void find_peak_subpixel_scalar(const float*, int, int, float&, int&, int&, float&, float&);

// Declare RVV functions
extern void complex_multiply_rvv(const float*, const float*, const float*, const float*, float*, float*, int);
extern void gaussian_correlation_rvv(const float*, float*, float, float, float, int);
extern void find_peak_subpixel_rvv(const float*, int, int, float&, int&, int&, float&, float&);

int main() {
    std::cout << "Running RVV vs Scalar Correctness Tests...\n";
    int size = 1024;
    std::vector<float> a_re(size), a_im(size), b_re(size), b_im(size);
    std::vector<float> out_re_s(size), out_im_s(size);
    std::vector<float> out_re_r(size), out_im_r(size);

    // Initialize with random data
    for (int i = 0; i < size; i++) {
        a_re[i] = (float)rand() / RAND_MAX;
        a_im[i] = (float)rand() / RAND_MAX;
        b_re[i] = (float)rand() / RAND_MAX;
        b_im[i] = (float)rand() / RAND_MAX
        ;}

    // --- Test K5.1: Complex Multiply ---
    complex_multiply_scalar(a_re.data(), a_im.data(), b_re.data(), b_im.data(), out_re_s.data(), out_im_s.data(), size);
    complex_multiply_rvv(a_re.data(), a_im.data(), b_re.data(), b_im.data(), out_re_r.data(), out_im_r.data(), size);
    
    double max_err_re = 0, max_err_im = 0;
    for (int i = 0; i < size; i++) { // Line 38-39: Cast fabs to float
        max_err_re = std::max(max_err_re, (float)fabs(out_re_s[i] - out_re_r[i]));
        max_err_im = std::max(max_err_im, (float)fabs(out_im_s[i] - out_im_r[i]));
    }
    std::cout << "K5.1 Max Error (Re): " << max_err_re << ", (Im): " << max_err_im << "\n";
    assert(max_err_re < 1e-4f && max_err_im < 1e-4f);
    std::cout << "[PASS] K5.1 Complex Multiply RVV\n";

    // --- Test K5.2: Gaussian Correlation ---
    std::vector<float> corr(size);
    std::vector<float> kern_s(size), kern_r(size);
    for(int i=0; i<size; i++) corr[i] = 5.0f + ((float)rand() / RAND_MAX) * 5.0f; // Realistic IFFT output
    
    gaussian_correlation_scalar(corr.data(), kern_s.data(), 14.0f, 14.0f, 2.0f, size);
    gaussian_correlation_rvv(corr.data(), kern_r.data(), 14.0f, 14.0f, 2.0f, size);
    
    double max_err_k = 0;
    for (int i = 0; i < size; i++) { // Line 55: Same fix
        max_err_k = std::max(max_err_k, (float)fabs(kern_s[i] - kern_r[i]));
    }
    std::cout << "K5.2 Max Error (Gaussian): " << max_err_k << "\n";
    assert(max_err_k < 1e-3f); // Slightly higher tolerance due to exp() polynomial approximation
    std::cout << "[PASS] K5.2 Gaussian Correlation RVV\n";

    // --- Test K6: Peak Detection ---
    int rows = 64, cols = 64;
    std::vector<float> response(rows * cols, 0.0f);
    response[32 * cols + 32] = 10.0f; // Peak
    response[32 * cols + 31] = 5.0f;
    response[32 * cols + 33] = 5.0f;
    response[31 * cols + 32] = 5.0f;
    response[33 * cols + 32] = 5.0f;
    
    float max_val_s, max_val_r, sub_x_s, sub_y_s, sub_x_r, sub_y_r;
    int max_x_s, max_y_s, max_x_r, max_y_r;
    
    find_peak_subpixel_scalar(response.data(), rows, cols, max_val_s, max_x_s, max_y_s, sub_x_s, sub_y_s);
    find_peak_subpixel_rvv(response.data(), rows, cols, max_val_r, max_x_r, max_y_r, sub_x_r, sub_y_r);
    
    assert(max_x_s == max_x_r && max_y_s == max_y_r);
    assert(fabs(sub_x_s - sub_x_r) < 1e-4f && fabs(sub_y_s - sub_y_r) < 1e-4f);
    std::cout << "[PASS] K6 Peak Detection RVV\n";

    std::cout << "\nAll RVV correctness tests passed successfully!\n";
    return 0;
}