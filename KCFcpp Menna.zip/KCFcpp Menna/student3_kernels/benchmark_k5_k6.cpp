#include <iostream>
#include <vector>
#include <chrono>
#include <cmath>
#include <cstdlib>

extern void complex_multiply_scalar(const float*, const float*, const float*, const float*, float*, float*, int);
extern void complex_multiply_rvv(const float*, const float*, const float*, const float*, float*, float*, int);
extern void gaussian_correlation_scalar(const float*, float*, float, float, float, int);
extern void gaussian_correlation_rvv(const float*, float*, float, float, float, int);

int main() {
    int rows = 128, cols = 128;
    int size = rows * cols; 
    int iterations = 1000;

    std::vector<float> a_re(size), a_im(size), b_re(size), b_im(size);
    std::vector<float> out_re(size), out_im(size);
    std::vector<float> corr(size), kernel_out(size);

    for (int i = 0; i < size; i++) {
        a_re[i] = (float)rand() / RAND_MAX;
        a_im[i] = (float)rand() / RAND_MAX;
        b_re[i] = (float)rand() / RAND_MAX;
        b_im[i] = (float)rand() / RAND_MAX;
        corr[i] = 5.0f + ((float)rand() / RAND_MAX) * 5.0f;
    }

    auto start = std::chrono::high_resolution_clock::now();
    auto end = std::chrono::high_resolution_clock::now();
    double time_ms;

    std::cout << "--- K5.1 Complex Multiply (Size: " << size << ") ---\n";
    start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < iterations; i++) {
        complex_multiply_scalar(a_re.data(), a_im.data(), b_re.data(), b_im.data(), out_re.data(), out_im.data(), size);
    }
    end = std::chrono::high_resolution_clock::now();
    time_ms = std::chrono::duration<double, std::milli>(end - start).count();
    std::cout << "Scalar: " << time_ms << " ms (" << time_ms/iterations << " ms/iter)\n";

    start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < iterations; i++) {
        complex_multiply_rvv(a_re.data(), a_im.data(), b_re.data(), b_im.data(), out_re.data(), out_im.data(), size);
    }
    end = std::chrono::high_resolution_clock::now();
    time_ms = std::chrono::duration<double, std::milli>(end - start).count();
    std::cout << "RVV:    " << time_ms << " ms (" << time_ms/iterations << " ms/iter)\n\n";

    std::cout << "--- K5.2 Gaussian Correlation (Size: " << size << ") ---\n";
    start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < iterations; i++) {
        gaussian_correlation_scalar(corr.data(), kernel_out.data(), 14.0f, 14.0f, 2.0f, size);
    }
    end = std::chrono::high_resolution_clock::now();
    time_ms = std::chrono::duration<double, std::milli>(end - start).count();
    std::cout << "Scalar: " << time_ms << " ms (" << time_ms/iterations << " ms/iter)\n";

    start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < iterations; i++) {
        gaussian_correlation_rvv(corr.data(), kernel_out.data(), 14.0f, 14.0f, 2.0f, size);
    }
    end = std::chrono::high_resolution_clock::now();
    time_ms = std::chrono::duration<double, std::milli>(end - start).count();
    std::cout << "RVV:    " << time_ms << " ms (" << time_ms/iterations << " ms/iter)\n";

    return 0;
}
